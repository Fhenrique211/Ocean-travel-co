# Oceania Travel Co.

Site de roteiros de viagem da Oceania Travel Co.

## Estrutura

- `index.html`: o site inteiro (páginas, estilo e código)
- `assets/img`: fotos e imagens
- `assets/video`: vídeos do roteiro e dos hotéis
- `assets/fonts`: fontes usadas no site

## Como publicar no GitHub Pages

1. No GitHub, crie um repositório novo (por exemplo, `oceania-travel-co`), marcado como **Public**.
2. Clique em **Add file > Upload files** e arraste o **conteúdo** desta pasta: o `index.html`, o `README.md` e a pasta `assets`.
3. Clique em **Commit changes**.
4. Vá em **Settings > Pages**. Em **Branch**, escolha `main` e a pasta `/ (root)` e clique em **Save**.
5. Em alguns minutos o site fica disponível em `https://SEU-USUARIO.github.io/oceania-travel-co/`.

## Observações

- As fotos dos "Próximos roteiros" vêm do Wikimedia Commons e carregam pela internet. Os créditos estão na própria página.
- Os preços do orçamento foram pesquisados em outubro de 2026 e são valores de planejamento.
